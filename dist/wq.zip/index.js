"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const userRoutes_1 = __importDefault(require("./routes/userRoutes"));
const orderRoutes_1 = __importDefault(require("./routes/orderRoutes"));
const performaRoutes_1 = __importDefault(require("./routes/performaRoutes"));
const shipmentRoutes_1 = __importDefault(require("./routes/shipmentRoutes"));
const itemRoutes_1 = __importDefault(require("./routes/itemRoutes"));
const fileUpload_1 = __importDefault(require("./routes/fileUpload"));
const clearnceRoute_1 = __importDefault(require("./routes/clearnceRoute"));
const shipmentgldataRoute_1 = __importDefault(require("./routes/shipmentgldataRoute"));
const lcttRoute_1 = __importDefault(require("./routes/lcttRoute"));
const shipmentsheduleRoute_1 = __importDefault(require("./routes/shipmentsheduleRoute"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use((0, cookie_parser_1.default)());
const port = 5000;
var corsOptions = {
    origin: true,
    credentials: true
};
app.use((0, cors_1.default)(corsOptions));
app.use('/api/users', userRoutes_1.default);
app.use('/api/orders', orderRoutes_1.default);
app.use('/api/performa', performaRoutes_1.default);
app.use('/api/shipment', shipmentRoutes_1.default);
app.use('/api/items', itemRoutes_1.default);
app.use('/api/upload', fileUpload_1.default);
app.use('/api/clearance', clearnceRoute_1.default);
app.use('/api/shipmentshedule', shipmentsheduleRoute_1.default);
app.use('/api/shipmentgldata', shipmentgldataRoute_1.default);
app.use('/api/lctt', lcttRoute_1.default);
const database_providers_1 = require("./config/database.providers");
database_providers_1.myDataSource.initialize()
    .then(() => {
    console.log("Data Source has been initialized!");
})
    .catch((err) => {
    console.error("Error during Data Source initialization:", err);
});
database_providers_1.myDataSource1.initialize()
    .then(() => {
    console.log("Data Source has been initialized!");
})
    .catch((err) => {
    console.error("Error during Data Source initialization:", err);
});
/*
// register routes
app.get("/users", async function (req: Request, res: Response) {
const userRepository = myDataSource.getRepository(Category)

const users = await userRepository.find({
relations: {
 posts: true,
},
})


res.json(users)
})

*/
app.get('/', (req, res) => {
    res.send('API is running....');
});
app.listen(port, () => console.log(`Server started on port ${port}`));
//# sourceMappingURL=index.js.map