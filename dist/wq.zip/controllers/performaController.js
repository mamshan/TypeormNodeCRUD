"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.update = exports.getData = exports.register = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const Performa_1 = require("../entity/Performa");
const database_providers_1 = require("../config/database.providers");
// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const register = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { orderNo, piNo, piDate, value, rate, paymentRef, paymentDate, paymentValue, tolerance, loanApplied, loanGranted, usancePeriod, expiryDate, amendments, remarks, insuranceDate, debitNote, policy, insuracePaymentDt, insuraceCancellDt, performaItems } = req.body;
    const bank = req.body.bank.code;
    const currency = req.body.currency.code;
    const deliveryTerms = req.body.deliveryTerms.code;
    const paymentTerm = req.body.paymentTerm.code;
    const userRepository = database_providers_1.myDataSource.getRepository(Performa_1.Performa);
    const entryExists = yield userRepository.findOne({ where: { piNo: piNo } });
    if (entryExists) {
        res.status(400);
        throw new Error('Entry already exists');
    }
    const entry = yield userRepository.save({
        orderNo,
        piNo,
        piDate,
        bank,
        currency,
        value,
        rate,
        deliveryTerms,
        paymentTerm,
        paymentRef,
        paymentDate,
        paymentValue,
        tolerance,
        loanApplied,
        loanGranted,
        usancePeriod,
        expiryDate,
        amendments,
        remarks,
        insuranceDate,
        debitNote,
        policy,
        insuracePaymentDt,
        insuraceCancellDt,
    });
    const performa = entry.id;
    const orderitemsls = performaItems.map((item) => (Object.assign(Object.assign({}, item), { performa })));
    const userRepositoryitms = database_providers_1.myDataSource.getRepository(Performa_1.PerformaItems);
    const orderls = yield userRepositoryitms.save(orderitemsls);
    if (entry) {
        res.status(201).json({
            entry: entry,
            PerformaItems: orderls
        });
    }
    else {
        res.status(400);
        throw new Error('Invalid Order data');
    }
}));
exports.register = register;
// @desc    Get user profile
// @route   GET /api/orders/profile
// @access  Private
const getData = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource.getRepository(Performa_1.Performa);
    const entries = yield userRepository.find({
        relations: {
            PerformaItems: true,
        },
        order: {
            piDate: "DESC",
        },
    });
    if (entries) {
        res.json({
            entries: entries
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.getData = getData;
const update = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource.getRepository(Performa_1.Performa);
    const entry = yield userRepository.findOne({ where: { id: req.body.id } });
    const { orderNo, piNo, piDate, value, rate, paymentRef, paymentDate, paymentValue, tolerance, loanApplied, loanGranted, usancePeriod, expiryDate, amendments, remarks, insuranceDate, debitNote, policy, insuracePaymentDt, insuraceCancellDt, performaItems } = req.body;
    if (entry) {
        const updatentry = yield userRepository.update({ id: req.body.id }, {
            orderNo,
            piNo,
            piDate,
            value,
            rate,
            paymentRef,
            paymentDate,
            paymentValue,
            tolerance,
            loanApplied,
            loanGranted,
            usancePeriod,
            expiryDate,
            amendments,
            remarks,
            insuranceDate,
            debitNote,
            policy,
            insuracePaymentDt,
            insuraceCancellDt
        });
        const performa = entry.id;
        const itemsls = performaItems.map((item) => (Object.assign(Object.assign({}, item), { performa })));
        const userRepositoryitms = database_providers_1.myDataSource.getRepository(Performa_1.PerformaItems);
        const userToDelete = yield userRepositoryitms.find({ where: { performa: req.body.id } });
        yield userRepositoryitms.delete({ performa: req.body.id });
        const entryls = yield userRepositoryitms.save(itemsls);
        res.json({
            id: req.body.id
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.update = update;
//# sourceMappingURL=performaController.js.map