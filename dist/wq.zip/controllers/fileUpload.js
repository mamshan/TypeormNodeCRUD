"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFile = exports.getFiles = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const path_1 = __importDefault(require("path"));
const database_providers_1 = require("../config/database.providers");
const getFiles = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const __dirname = path_1.default.resolve();
    const uploadsDirectory = path_1.default.join(__dirname, 'uploads/');
    const queryRunner = database_providers_1.myDataSource.createQueryRunner();
    const brands = yield queryRunner.manager.query("select * from files where docid='" + req.query.docid + "' and doctype='" + req.query.doctype + "'");
    const items = [];
    for (const result of brands) {
        const item = {
            id: result.id,
            reference: result.reference,
            filename: 'uploads/' + result.filename,
        };
        items.push(item);
    }
    if (brands) {
        res.json({
            files: items,
        });
    }
    else {
        res.status(404);
        throw new Error('Order not found');
    }
}));
exports.getFiles = getFiles;
const deleteFile = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const __dirname = path_1.default.resolve();
    const uploadsDirectory = path_1.default.join(__dirname, 'uploads/');
    const queryRunner = database_providers_1.myDataSource.createQueryRunner();
    const deleteQ = yield queryRunner.manager.query("delete  from files where id='" + req.query.docid + "' and doctype='" + req.query.doctype + "'");
    const brands = yield queryRunner.manager.query("select * from files where docid='" + req.query.docid + "' and doctype='" + req.query.doctype + "'");
    const items = [];
    for (const result of brands) {
        const item = {
            id: result.id,
            reference: result.reference,
            filename: 'uploads/' + result.filename,
        };
        items.push(item);
    }
    if (brands) {
        res.json({
            files: items,
        });
    }
    else {
        res.status(404);
        throw new Error('Order not found');
    }
}));
exports.deleteFile = deleteFile;
//# sourceMappingURL=fileUpload.js.map