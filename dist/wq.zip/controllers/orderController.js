"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateOrders = exports.getOrders = exports.registerOrder = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const Orders_1 = require("../entity/Orders");
const database_providers_1 = require("../config/database.providers");
const registerOrder = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { orderNo, orderDate, orderItems } = req.body;
    const supplier = req.body.supplier.code;
    const buyer = req.body.buyer.code;
    const userRepository = database_providers_1.myDataSource.getRepository(Orders_1.Order);
    const orderExists = yield userRepository.findOne({ where: { orderNo: orderNo } });
    if (orderExists) {
        res.status(400);
        throw new Error('Order already exists');
    }
    const orderent = yield userRepository.save({
        orderNo,
        orderDate,
        supplier,
        buyer
    });
    const order = orderent.id;
    const orderitemsls = orderItems.map((item) => (Object.assign(Object.assign({}, item), { order })));
    const userRepositoryitms = database_providers_1.myDataSource.getRepository(Orders_1.OrderItems);
    const orderls = yield userRepositoryitms.save(orderitemsls);
    if (orderent) {
        res.status(201).json({
            entry: orderent,
            OrderItems: orderitemsls
        });
    }
    else {
        res.status(400);
        throw new Error('Invalid Order data');
    }
}));
exports.registerOrder = registerOrder;
const getOrders = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource.getRepository(Orders_1.Order);
    const orders = yield userRepository.find({
        relations: {
            OrderItems: true,
        },
        order: {
            orderDate: "DESC",
        },
    });
    if (orders) {
        res.json({
            orders: orders
        });
    }
    else {
        res.status(404);
        throw new Error('Order not found');
    }
}));
exports.getOrders = getOrders;
const updateOrders = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource.getRepository(Orders_1.Order);
    const order = yield userRepository.findOne({ where: { id: req.body.id } });
    const { orderNo, orderDate, orderItems } = req.body;
    const supplier = req.body.supplier.code;
    const buyer = req.body.buyer.code;
    if (order) {
        // Update the order
        const updatedorder = yield userRepository.update({ id: req.body.id }, {
            orderNo,
            orderDate,
            supplier,
            buyer,
        });
        const order = req.body.id;
        // Delete existing order items
        // await OrderItems.destroy({
        // where: { orderId: orderId },
        //});
        // Create/update order items
        //  await OrderItems.bulkCreate(orderItems.map((item) => ({ ...item, orderId })), { validate: true });
        const orderitemsls = orderItems.map((item) => (Object.assign(Object.assign({}, item), { order })));
        const userRepositoryitms = database_providers_1.myDataSource.getRepository(Orders_1.OrderItems);
        const userToDelete = yield userRepositoryitms.find({ where: { order: req.body.id } });
        yield userRepositoryitms.delete({ order: req.body.id });
        const orderls = yield userRepositoryitms.save(orderitemsls);
        res.json({
            id: req.body.id,
        });
    }
    else {
        res.status(404);
        throw new Error('Order not found');
    }
}));
exports.updateOrders = updateOrders;
//# sourceMappingURL=orderController.js.map