"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserProfile = exports.authUser = void 0;
const Users_1 = require("../entity/Users");
const database_providers_1 = require("../config/database.providers");
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const generateToken_1 = __importDefault(require("../utils/generateToken"));
const authUser = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { username, password } = req.body;
    const userRepository = database_providers_1.myDataSource.getRepository(Users_1.Users);
    const user = yield userRepository.findOne({ where: { name: username } });
    if (user && (yield user.matchPassword(password))) {
        (0, generateToken_1.default)(res, user.id, user.name);
        res.json({
            id: user.id,
            name: user.name,
            username: user.email,
        });
    }
    else {
        res.status(401);
        throw new Error('Invalid email or password');
    }
}));
exports.authUser = authUser;
const getUserProfile = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    let token;
    token = req.cookies.jwt;
    const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
    const userRepository = database_providers_1.myDataSource.getRepository(Users_1.Users);
    const user = yield userRepository.findOne({ where: { id: req.user.id } });
    if (user) {
        res.json({
            id: user.id,
            name: user.name,
            email: user.email,
        });
    }
    else {
        res.status(404);
        throw new Error('User not found');
    }
}));
exports.getUserProfile = getUserProfile;
//# sourceMappingURL=userController.js.map