"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.update = exports.getData = exports.register = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const clearnceModel_1 = require("../entity/clearnceModel");
const database_providers_1 = require("../config/database.providers");
// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const register = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { shipmentNo, cleanceDate, clearValue, loanDate, shipmentCleardt, remarks } = req.body;
    const bank = req.body.bank.code;
    const userRepository = database_providers_1.myDataSource.getRepository(clearnceModel_1.Clearnce);
    const entryExists = yield userRepository.findOne({ where: { shipmentNo: shipmentNo } });
    if (entryExists) {
        res.status(400);
        throw new Error('Entry already exists');
    }
    const entry = yield userRepository.save({
        shipmentNo,
        cleanceDate,
        clearValue,
        loanDate,
        bank,
        shipmentCleardt,
        remarks
    });
    if (entry) {
        res.status(201).json({
            entry: entry,
        });
    }
    else {
        res.status(400);
        throw new Error('Invalid Data');
    }
}));
exports.register = register;
// @desc    Get user profile
// @route   GET /api/orders/profile
// @access  Private
const getData = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource.getRepository(clearnceModel_1.Clearnce);
    const entries = yield userRepository.find({
        order: {
            shipmentCleardt: "DESC",
        },
    });
    if (entries) {
        res.json({
            entries: entries
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.getData = getData;
const update = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource.getRepository(clearnceModel_1.Clearnce);
    const entry = yield userRepository.findOne({ where: { id: req.body.id } });
    if (entry) {
        const { shipmentNo, cleanceDate, clearValue, loanDate, shipmentCleardt, remarks } = req.body;
        const bank = req.body.bank.code;
        const updatentry = yield userRepository.update({ id: req.body.id }, {
            shipmentNo,
            cleanceDate,
            clearValue,
            loanDate,
            shipmentCleardt,
            remarks,
            bank
        });
        const updatedentry = yield userRepository.findOne({ where: { id: req.body.id } });
        res.json({
            id: updatedentry.id,
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.update = update;
//# sourceMappingURL=clearnceController.js.map