"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLcno = exports.update = exports.getData = exports.register = void 0;
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const lcttModel_1 = require("../entity/lcttModel");
const database_providers_1 = require("../config/database.providers");
// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const register = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { lc_tr_no, sdate, cur, rate, amount, lkr_val, lo_due_date, exp_date, exp_date2, our_ref, supp, } = req.body;
    const code = req.body.bank.code;
    const flag = "LC";
    const sdate1 = sdate;
    const userRepository = database_providers_1.myDataSource1.getRepository(lcttModel_1.lc_tr);
    const entryExists = yield userRepository.findOne({ where: { lc_tr_no: lc_tr_no } });
    if (entryExists) {
        res.status(400);
        throw new Error('Entry already exists');
    }
    const entry = yield userRepository.save({
        lc_tr_no,
        sdate,
        sdate1,
        cur,
        rate,
        amount,
        lkr_val,
        lo_due_date,
        exp_date,
        exp_date2,
        our_ref,
        supp,
        code,
        flag
    });
    if (entry) {
        res.json({
            entry: entry,
        });
    }
    else {
        res.status(400);
        throw new Error('Invalid Order data');
    }
}));
exports.register = register;
// @desc    Get user profile
// @route   GET /api/orders/profile
// @access  Private
const getData = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const flag = "LC";
    const userRepository = database_providers_1.myDataSource1.getRepository(lcttModel_1.lc_tr);
    console.log("dsef1s");
    const entries = yield userRepository.find({
        where: { flag: flag, },
        order: {
            sdate: "DESC",
        },
    });
    if (entries) {
        res.json({
            entries: entries
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.getData = getData;
const getLcno = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const refNo = req.params.refNo;
    const userRepository = database_providers_1.myDataSource1.getRepository(lcttModel_1.lc_tr);
    const entry = yield userRepository.findOne({ where: { lc_tr_no: refNo } });
    if (entry) {
        res.json({
            entry: entry
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.getLcno = getLcno;
const update = (0, express_async_handler_1.default)((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const userRepository = database_providers_1.myDataSource1.getRepository(lcttModel_1.lc_tr);
    const entry = yield userRepository.findOne({ where: { id: req.body.id } });
    const { lc_tr_no, sdate, cur, rate, amount, lkr_val, lo_due_date, exp_date, exp_date2, our_ref, supp, } = req.body;
    const code = req.body.bank.code;
    const flag = "LC";
    const sdate1 = sdate;
    if (entry) {
        const updatentry = yield userRepository.update({ id: req.body.id }, {
            lc_tr_no,
            sdate,
            sdate1,
            cur,
            rate,
            amount,
            lkr_val,
            lo_due_date,
            exp_date,
            exp_date2,
            our_ref,
            supp,
            code,
            flag
        });
        const updatedentry = yield userRepository.findOne({ where: { id: req.body.id } });
        res.json({
            entry: updatedentry,
        });
    }
    else {
        res.status(404);
        throw new Error('Not found');
    }
}));
exports.update = update;
//# sourceMappingURL=lcttController.js.map