declare class lc_tr {
    id: number;
    lc_tr_no: string;
    code: string;
    name: string;
    sdate: Date;
    sdate1: Date;
    cur: string;
    rate: string;
    amount: string | null;
    lkr_val: string | null;
    lo_due_date: string | null;
    exp_date: Date | null;
    exp_date2: Date | null;
    our_ref: string | null;
    supp: string | null;
    flag: string | null;
    createdAt: Date;
    updatedAt: Date;
}
export { lc_tr };
