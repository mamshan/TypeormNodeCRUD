declare class Order {
    id: number;
    orderNo: string;
    orderDate: Date;
    supplier: string;
    buyer: string;
    OrderItems: OrderItems[];
}
declare class OrderItems {
    id: number;
    code: string;
    description: string;
    qty: number;
    order: Order[];
}
export { Order, OrderItems };
