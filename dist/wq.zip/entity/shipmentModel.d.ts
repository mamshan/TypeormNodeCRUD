declare class Shipment {
    id: number;
    piNo: string;
    shipmentNo: string;
    invoiceNo: string;
    invoiceDate: string;
    invoiceValue: string;
    blNo: string;
    blDate: string;
    maturityDate: string;
    arrivalDate: string;
    bankDocumentType: string;
    bankDocumentDate: string;
    bankorgiginalDate: string;
    bankcancelledDate: string;
    bankexchangeRate: string;
    bankloanApplied: string;
    bankloanGranted: string;
    bankRemarks: string;
    freightDate: string;
    freightAgent: string;
    freightCharges: string;
    freightLocalCharges: string;
    freightPaidBy: string;
    freightContainer: string;
    freightBlno: string;
    freightRefundable: string;
    freightFclDate: string;
    freightSendCollect: string;
    freightRefund: string;
    freightChequ: string;
    ShipmentItems: ShipmentItems[];
}
declare class ShipmentItems {
    id: number;
    code: string;
    description: string;
    qty: number;
    piqty: number;
    fob: number;
    shipment: Shipment[];
}
export { Shipment, ShipmentItems };
