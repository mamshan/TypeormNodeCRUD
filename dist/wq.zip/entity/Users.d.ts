export declare class Users {
    id: number;
    name: string;
    email: string;
    password: string;
    hashPasswordBeforeInsert(): Promise<void>;
    hashPasswordBeforeUpdate(): Promise<void>;
    matchPassword(enteredPassword: string): Promise<boolean>;
}
