declare class Performa {
    id: number;
    orderNo: string;
    piNo: string;
    piDate: string;
    bank: string;
    currency: string;
    value: string;
    rate: string;
    deliveryTerms: string;
    paymentTerm: string;
    paymentRef: string;
    paymentDate: string;
    paymentValue: string;
    tolerance: string;
    loanApplied: string;
    loanGranted: string;
    usancePeriod: string;
    expiryDate: string;
    amendments: string;
    remarks: string;
    insuranceDate: string;
    debitNote: string;
    policy: string;
    insuracePaymentDt: string;
    insuraceCancellDt: string;
    createdAt: Date;
    updatedAt: Date;
    PerformaItems: PerformaItems[];
}
declare class PerformaItems {
    id: number;
    code: string;
    description: string;
    qty: number;
    piqty: number;
    fob: number;
    performa: Performa[];
}
export { Performa, PerformaItems };
