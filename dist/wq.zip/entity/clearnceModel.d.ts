declare class Clearnce {
    id: number;
    shipmentNo: string;
    cleanceDate: Date;
    clearValue: string;
    bank: string;
    loanDate: Date;
    remarks: string;
    shipmentCleardt: Date;
}
export { Clearnce };
