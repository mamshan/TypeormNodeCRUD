declare const generateToken: (res: any, userId: any, userName: any) => void;
export default generateToken;
