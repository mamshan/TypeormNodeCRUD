"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myDataSource1 = exports.myDataSource = void 0;
require("reflect-metadata");
const typeorm_1 = require("typeorm");
const Post_1 = require("../entity/Post");
const Orders_1 = require("../entity/Orders");
const Performa_1 = require("../entity/Performa");
const shipmentModel_1 = require("../entity/shipmentModel");
const clearnceModel_1 = require("../entity/clearnceModel");
const Users_1 = require("../entity/Users");
const lcttModel_1 = require("../entity/lcttModel");
const myDataSource = new typeorm_1.DataSource({
    type: "mysql",
    host: "localhost",
    username: "genappsw_payroll",
    password: "w~WhF!-HuP5N",
    database: "genappsw_payroll",
    synchronize: true,
    logging: true,
    entities: [Post_1.Post, Post_1.Category, Orders_1.Order, Orders_1.OrderItems, Users_1.Users, Performa_1.Performa, Performa_1.PerformaItems, shipmentModel_1.Shipment, shipmentModel_1.ShipmentItems, clearnceModel_1.Clearnce, lcttModel_1.lc_tr],
    subscribers: [],
    migrations: [],
});
exports.myDataSource = myDataSource;
const myDataSource1 = new typeorm_1.DataSource({
    type: "sqlite",
    database: "./database.sqlite",
    synchronize: false,
    logging: true,
    entities: [Post_1.Post, Post_1.Category, Orders_1.Order, Orders_1.OrderItems, Users_1.Users],
    subscribers: [],
    migrations: [],
});
exports.myDataSource1 = myDataSource1;
//# sourceMappingURL=database.providers.js.map