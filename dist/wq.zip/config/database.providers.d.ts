import "reflect-metadata";
import { DataSource } from "typeorm";
declare const myDataSource: DataSource;
declare const myDataSource1: DataSource;
export { myDataSource, myDataSource1 };
