"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const database_providers_1 = require("../config/database.providers");
const router = express_1.default.Router();
router.get('/', getReportView);
function getReportView(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const queryRunner = database_providers_1.myDataSource.createQueryRunner();
        const queryRunner1 = database_providers_1.myDataSource1.createQueryRunner();
        try {
            const refno = req.query.ref;
            const purdetails = yield queryRunner.manager.query(`SELECT refno,department,lcno,sdate FROM viewarn where lcno like '%${refno}%' group by refno,department,lcno,sdate`);
            const gldebits = yield queryRunner1.manager.query(`SELECT * FROM view_ledger where l_flag1='DEB'and L_LMEM like '%${refno}%' order by l_refno`);
            const glcredits = yield queryRunner1.manager.query(`SELECT * FROM view_ledger where l_flag1='CRE'and L_LMEM like '%${refno}%' order by l_refno`);
            const itemm = [];
            for (const result of purdetails) {
                const puritems = yield queryRunner.manager.query(`SELECT * FROM viewarn where refno = '${result.refno}'`);
                const items = [];
                var shipqty = 0;
                for (const result1 of puritems) {
                    const item = {
                        brand_name: result1.BRAND_NAME,
                        size: result1.SIZE,
                        stk_no: result1.STK_NO,
                        qty: result1.REC_QTY,
                    };
                    shipqty = shipqty + result1.REC_QTY;
                    items.push(item);
                }
                var dep = result.department;
                if (dep == "01") {
                    dep = "KELANIYA";
                }
                if (dep == "18") {
                    dep = "GONAWALA";
                }
                const itemmS = {
                    refno: result.refno,
                    department: dep,
                    sdate: result.sdate,
                    lcno: result.lcno,
                    qty: shipqty,
                    items: items,
                };
                itemm.push(itemmS);
            }
            res.json({
                purdetails: itemm,
                gldebits: gldebits,
                glcredits: glcredits,
            });
        }
        catch (error) {
            console.error('Error storing file data in MySQL:', error);
            res.status(500).send('Error storing file data in MySQL');
        }
    });
}
exports.default = router;
//# sourceMappingURL=shipmentgldataRoute.js.map