"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const lcttController_1 = require("../controllers/lcttController");
const router = express_1.default.Router();
router.post('/', lcttController_1.register);
router.get('/', lcttController_1.getData);
router.put('/', lcttController_1.update);
router.get('/:refNo', lcttController_1.getLcno);
exports.default = router;
//# sourceMappingURL=lcttRoute.js.map