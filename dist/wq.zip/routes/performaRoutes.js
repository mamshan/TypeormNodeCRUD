"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const performaController_1 = require("../controllers/performaController");
const router = express_1.default.Router();
router.post('/', performaController_1.register);
router.get('/', performaController_1.getData);
router.put('/', performaController_1.update);
exports.default = router;
//# sourceMappingURL=performaRoutes.js.map