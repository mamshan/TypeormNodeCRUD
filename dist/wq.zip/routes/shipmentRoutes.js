"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const shipmentController_1 = require("../controllers/shipmentController");
const router = express_1.default.Router();
router.post('/', shipmentController_1.register);
router.get('/', shipmentController_1.getData);
router.put('/', shipmentController_1.update);
exports.default = router;
//# sourceMappingURL=shipmentRoutes.js.map