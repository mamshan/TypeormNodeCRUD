"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fileUpload_1 = require("../controllers/fileUpload");
const database_providers_1 = require("../config/database.providers");
const router = express_1.default.Router();
const storage = multer_1.default.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.originalname + '-' + uniqueSuffix + path_1.default.extname(file.originalname));
    }
});
const upload = (0, multer_1.default)({ storage: storage });
router.post("/", upload.array("files"), uploadFiles);
router.get('/', fileUpload_1.getFiles);
router.delete('/', fileUpload_1.deleteFile);
function uploadFiles(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const files = req.files; // Get the uploaded files
        const queryBuilder = database_providers_1.myDataSource.createQueryBuilder();
        const fileData = files.map(file => [
            file.filename,
            file.originalname,
            req.body.docid,
            req.body.doctype
        ]);
        try {
            yield queryBuilder
                .insert()
                .into('files')
                .values(fileData)
                .execute();
            res.json({
                files: req.files,
            });
        }
        catch (error) {
            console.error('Error storing file data in MySQL:', error);
            res.status(500).send('Error storing file data in MySQL');
        }
    });
}
exports.default = router;
//# sourceMappingURL=fileUpload.js.map